package com.capgemini.service;

public interface IPasswordService {

	public void updatePassword(String pass, String newPass, String confirmPass);

}
