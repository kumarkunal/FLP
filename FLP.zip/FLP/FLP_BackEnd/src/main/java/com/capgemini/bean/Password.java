package com.capgemini.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Password {
	
	
	@Column(name="oldPassword")
	private String old_pass;
	
	@Id
	@Column(name="newPassword")
	private String new_pass;
	
	
	
	public Password()
	{
		
	}
	public Password(String old_pass, String new_pass) {
		super();
		this.old_pass = old_pass;
		this.new_pass = new_pass;
	}



	
	public String getOld_pass() {
		return old_pass;
	}
	public void setOld_pass(String old_pass) {
		this.old_pass = old_pass;
	}
	public String getNew_pass() {
		return new_pass;
	}
	public void setNew_pass(String new_pass) {
		this.new_pass = new_pass;
	}
	

}
