package com.capgemini.controller;

public class PasswordController {

}
