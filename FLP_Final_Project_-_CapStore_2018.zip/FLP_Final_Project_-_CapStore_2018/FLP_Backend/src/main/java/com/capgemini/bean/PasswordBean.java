package com.capgemini.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PasswordBean {
	
	public PasswordBean()
	{
		
	}
	
	public PasswordBean(String old_pass, String new_pass) {
		super();
		this.old_pass = old_pass;
		this.new_pass = new_pass;
	}


	@Id
	private String old_pass;
	private String new_pass;
	public String getOld_pass() {
		return old_pass;
	}
	public void setOld_pass(String old_pass) {
		this.old_pass = old_pass;
	}
	public String getNew_pass() {
		return new_pass;
	}
	public void setNew_pass(String new_pass) {
		this.new_pass = new_pass;
	}
	

}
