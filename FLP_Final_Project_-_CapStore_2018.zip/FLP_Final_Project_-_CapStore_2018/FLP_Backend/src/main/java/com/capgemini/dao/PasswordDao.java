package com.capgemini.dao;

public class PasswordDao {

}
