package com.capg.flp.FLP_152636;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.capg.flp.FLP_152636")
public class Flp152636Application {

	public static void main(String[] args) {
		SpringApplication.run(Flp152636Application.class, args);
	}
}
